$("document").ready(function() {
	
	$("#middle-headingDiv").tabs();
	

});