$("document").ready(function() {
	$("#top-dashboardDiv").tabs();
});