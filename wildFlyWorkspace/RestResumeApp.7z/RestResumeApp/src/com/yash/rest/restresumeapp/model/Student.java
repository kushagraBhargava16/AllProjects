package com.yash.rest.restresumeapp.model;

import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Student {
	private String name;
	private int studentId;
	private String city;
	private Map<Integer, Marks> marks;

	public Student() {

	}

	public Student(String name, int studentId, String city, Map<Integer, Marks> marks) {
		super();
		this.name = name;
		this.studentId = studentId;
		this.city = city;
		this.marks = marks;
	}

	public Map<Integer, Marks> getMarks() {
		return marks;
	}

	public void setMarks(Map<Integer, Marks> marks) {
		this.marks = marks;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
