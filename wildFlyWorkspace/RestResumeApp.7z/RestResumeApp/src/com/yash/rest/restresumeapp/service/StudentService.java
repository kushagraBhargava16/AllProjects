package com.yash.rest.restresumeapp.service;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.yash.rest.restresumeapp.model.Marks;
import com.yash.rest.restresumeapp.model.Student;

public class StudentService {
	public Map<Integer, Student> students = new TreeMap<>();

	public StudentService() {
		Marks tenthMarksSt1 = new Marks(1, 1, "high school", 420);
		Marks twelthMarksSt1 = new Marks(2, 1, "higher school", 390);
		Marks tenthMarksSt2 = new Marks(3, 2, "high school", 450);
		Marks twelthMarksSt2 = new Marks(4, 1, "higher school", 400);

		Map<Integer, Marks> marksSt1 = new HashMap();
		Map<Integer, Marks> marksSt2 = new HashMap();

		marksSt1.put(tenthMarksSt1.getMarksId(), tenthMarksSt1);
		marksSt1.put(twelthMarksSt1.getMarksId(), twelthMarksSt1);
		marksSt2.put(tenthMarksSt2.getMarksId(), tenthMarksSt2);
		marksSt2.put(twelthMarksSt2.getMarksId(), twelthMarksSt2);

		Student student1 = new Student("kushagra", 1, "indore", marksSt1);

		Student student2 = new Student("nikhil", 2, "dewas", marksSt2);

		students.put(1, student1);
		students.put(2, student2);
	}

	public Student fetchStudentById(int studentId) {

		return students.get(studentId);
	}

	public Student fetchStudentsByCity(String city) {
		
		return null;
	}

}
