package com.yash.ecommerce.beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import com.yash.ecommerce.domain.User;
import com.yash.ecommerce.services.UserService;

@ManagedBean
@SessionScoped
public class UserBeans {


	User user = new User();
	HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(true);
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Inject
	UserService service;
	public String checkLogin() {
		// service.authentication(username, password);
		//System.out.println(this.user.getName());
	
		session.setAttribute("user", user);
		//System.out.println(user);
		String check=service.authentication(user.getUsername(), user.getPassword());
		setUser(service.getUser(user.getUsername()));
		System.out.println(user);
		return check;
	}
	public String register(){
		
	return service.register(user);
	}

}
